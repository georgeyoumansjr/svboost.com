SEANA_ROOT=$(pwd)
export FLASK_APP=$SEANA_ROOT/main.py
export FLASK_ENV=development
