#!/bin/sh
git pull
touch tmp/restart.txt
